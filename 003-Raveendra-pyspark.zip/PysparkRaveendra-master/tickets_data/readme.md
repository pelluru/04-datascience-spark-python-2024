sample database called TICKET. This small database consists of seven tables: 
three fact tables and four dimensions. 
<img src="https://docs.aws.amazon.com/redshift/latest/dg/images/tickitdb.png">
