This folder contains list of images using for training content
