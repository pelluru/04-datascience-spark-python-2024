code
# Code
 
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fraveendratal%2FPysparkTelugu&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://hits.seeyoufarm.com)

![Raveendra's github stats](https://github-readme-stats.vercel.app/api?username=raveendratal&show_icons=true&hide_border=true)



<img align="right" alt="GIF"  width="300px" src="https://github.com/raveendratal/PysparkTelugu/blob/master/images/programming.gif" />

<h1 align="center">Hello 👋  : TR Raveendra <img src="https://github.com/raveendratal/PysparkTelugu/blob/master/images/Developer.gif" width="40px"></h1>
<h3 align="center"> Big Data With Cloud Data Engineering</h3><br>


<img align="right" alt="GIF"  width="300px" src="https://github.com/raveendratal/PysparkTelugu/blob/master/images/desktop.webp" />



[![Hello programmer Welcome to my profile](https://img.shields.io/badge/Hello,Programmer!-Welcome<3-brightgreen.svg?style=flat&logo=github)](https://github.com/raveendratal) [![Profile](https://Visitor-badge.glitch.me/badge?page_id=raveendratal.profileviews-badge)](https://github.com/raveendratal) [![Open Source Love](https://img.shields.io/github/followers/raveendratal?style=social)](https://github.com/raveendratal?tab=followers)[![Open Source Love](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/raveendratal)[![Repos Badge](https://badges.pufler.dev/repos/raveendratal)](https://badges.pufler.dev/repos/raveendratal)[![Connect on LinkedIn](https://img.shields.io/badge/--linkedin?label=LinkedIn&logo=LinkedIn&style=social)](https://www.linkedin.com/in/trraveendra/)
<br>
 
  
 
 
  #### 📫 How to reach me:   
  [<img src="https://github.com/sciencepal/sciencepal/blob/master/assets/discord-round.svg" width="3.5%"/>](https://github.com/raveendratal)
  [<img src="https://img.icons8.com/color/48/000000/linkedin.png" width="3.5%"/>](https://https://www.linkedin.com/in/trraveendra/)
  [<img src="https://img.icons8.com/fluent/48/000000/instagram-new.png" width="3.5%"/>](https://www.instagram.com/learningwithravi/?hl=en)
  <a href="mailto:tgrappstech@gmail.com"> <img src="https://img.icons8.com/fluent/48/000000/gmail.png" width="3.5%"/> </a>

</p>
<details>
  <summary>:zap: Tab here :P</summary>
  </details>  
 
